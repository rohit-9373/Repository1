// this program finds the area and volume of rectangle

#include<iostream>
using namespace std;

class Measure{
    public:
        int height;
        int width;
        int length;
        
        void setInput(int a,int b,int c) //it will set the input variables
        {
            height = a;
            width = b;
            length = c;
        }
        
        int area() // it will find area
        {
            return width*length; 
        }
        int volume() // it will find volume
        {
            return height*width*length;
        }
};

int main()
{
    Measure obj1,obj2;
    int h,w,l;
    obj1.setInput(10,20,30);
    obj2.setInput(40,50,60);
    cout<<"obj 1:"<<endl<<"area:"<<obj1.area()<<endl<<"volume:"<<obj1.volume()<<endl;
    cout<<"obj 2:"<<endl<<"area:"<<obj2.area()<<endl<<"volume:"<<obj2.volume()<<endl;
}
