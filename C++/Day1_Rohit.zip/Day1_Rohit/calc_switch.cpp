// calculator that performs multiple operations

#include<iostream>
using namespace std;

class just{
    public:
        int add(int a,int b)
        {
            return a+b;
        }
        int mul(int a,int b)
        {
            return a*b;
        }
        int div(int a,int b)
        {
            return a/b;
        }
         int substract(int a,int b)
        {
            return a-b;
        }
       
};

int main ()
{
   just obj1;
   int a,b,s;
   
   cout<<"enter a:";
   cin>>a;
   cout<<endl<<"enter b:";
   cin>>b;
   cout<<"1 addition"<<endl<<"2 substraction"<<endl<<"3 division"<<endl<<"4 multiplication"<<endl<<"enter choice:"; // it will print operation menu
   cin>>s;
   switch(s) // switch of operations
   {
        case 1:
        cout<<obj1.add(a,b);
        break;
         case 2:
        cout<<obj1.substract(a,b);
        break;
        case 3:
        cout<<obj1.div(a,b);
        break;
        case 4:
        cout<<obj1.mul(a,b);
        break;
        default:
        cout<<"invalid choice";
        break;
   }
  
 
}
