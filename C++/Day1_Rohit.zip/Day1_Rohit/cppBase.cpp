//Basic C++ Program that prints the squre

#include <iostream>
using namespace std;
int main() {
  int i;
  cout<<"This is output.\n";
  cout<<"enter a number:";
  cin>>i;
  cout<<i<<"\n"<<"squre is:"<<i*i;
 

    return 0;
}
