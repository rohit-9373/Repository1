// simple calculator that only performs addition with class

#include <iostream>
using namespace std;

class calculator{
    public:
        int input1;
        int input2;
        
        void setIn(int a,int b) // set the input
        {
            input1 = a;
            input2 = b;
        }
        int add() // addition
        {
            return input1+input2;
        }
};
int main() {
    calculator obj1;
    obj1.setIn(5,5);
  
  cout<<"sum is\n"<<obj1.add(); // printing the result
  
 

    return 0;
}
