// calculator that returns objects

#include <iostream>
using namespace std;

class calculator{
    public:
        int input1;
        int input2;
        
        int setInput(int a,int b)
        {
            input1 = a;
            input2 = b;
        }
     
        calculator add(calculator obj1,calculator obj2)
        {   calculator obj3;
            obj3.input1 = obj1.input1+obj2.input1;
            obj3.input2 = obj1.input2+obj2.input2;
            return obj3;   // returning an object
        }
};


int main() {
    calculator obj1,obj2,obj3;
    obj1.setInput(5,5);
    obj2.setInput(10,10);
    obj3 = obj3.add(obj1,obj2);
    cout<<"sum is\n"<<obj3.input1<<endl<<obj3.input2;
    return 0;
}




 

    
