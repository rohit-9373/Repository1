// extended version of calculator that can take object as an argument

#include <iostream>
using namespace std;

class calculator{
    public:
        int input1;
        int input2;
        
        int setInput(int a,int b)
        {
            input1 = a;
            input2 = b;
        }
     
        int add(calculator obj1,calculator obj2) 
        {   
            return obj1.input1+obj2.input2;
        }
};
int main() {
    calculator obj1,obj2;
    obj1.setInput(5,5);
    obj2.setInput(10,10);
  
    cout<<"sum is\n"<<obj1.add(obj1,obj2); // passing object as an argument
    return 0;
}


 

    
