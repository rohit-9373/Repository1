// program that prints current time and date also takes user inputs and prints age of that user

#include<iostream>
#include <ctime>
using namespace std;

class tim // time class
{
    private:
        int hour = 0;
        int minute = 0;
        int second = 0;
    public:
        void sleepTime(tim a,tim b)  // sleep time function
        {
            int i,j,k;
            if(a.hour-b.hour<0)
            {
                 i = -(a.hour-b.hour);
            }
            else
            {
                i = (a.hour-b.hour); 
            }
             if(a.minute-b.minute<0)
            {
                 j = -(a.minute-b.minute);
            }
            else
            {
                  j = (a.minute-b.minute);
            }
             if(a.second-b.second<0)
            {
                 k = -(a.second-b.second);
            }
            else
            {
                  k = (a.second-b.second);
            }
          
          cout<<"Hour:"<<i<<"\nminute:"<<j<<"\nSeconds:"<<k;
        }
        void setTime(int h,int m,int s) // set current time
        {
           hour = h;
           minute = m;
           second = s;
        }
        void getTime()
        {
          cout<<"hour:"<<hour<<"\nminute:"<<minute<<"\nseconds:"<<second;
        }
};

class dat // date class
{
    public:
        int day =0;
        int month =0;
        int year =0;

        dat setDate(int y,int m,int d)
        {
          dat cur;
          cur.day = d;
          cur.month = m;
          cur.year = y;
          return cur;
        }
        void getDate()
        {
           cout<<"current date:"<<endl;
           cout<<"year:"<<year<<endl<<"month:"<<month<<endl<<"day"<<day<<endl;
        }
         dat setDOB(int y,int m,int d)
        {
          dat DOB;
          DOB.day = d;
          DOB.month = m;
          DOB.year = y;
          return DOB;
        }
        int findAge(dat a,dat b) // it will find age
        {
            int c;
            c = a.year - b.year;
             return c;
        }

};

int main()
{
    tim obj1,obj2;
    dat object1,object2,object3;
    time_t now = time(0);
    tm *ltm = localtime(&now);;
    
    obj1.setTime(5+ltm->tm_hour,ltm->tm_min,ltm->tm_sec);
    cout<<"DOBrent time"<<endl<<"_____________"<<endl;
    obj1.getTime();
    obj2.setTime(10,10,15);
    cout<<"\n\nsleep time"<<endl<<"_____________"<<endl;
    obj1.sleepTime(obj1,obj2);
    cout<<"\n______________________________________\n";
    object3 = object1.setDate(1900 + ltm->tm_year,1 + ltm->tm_mon,ltm->tm_mday);
    cout<<endl<<"year:"<<object3.year<<endl<<"month:"<<object3.month<<endl<<"day:"<<object3.day<<endl;
    object2 = object1.setDOB(2001,04,10);
    cout<<endl<<"age:"<<object2.findAge(object3,object2)<<endl;
    
   
}
