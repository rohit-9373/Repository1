//extended version of calculator with class

#include <iostream>
using namespace std;

class calculator{
    public:
        int input1;
        int input2;
        int add();
        void setIn(int a,int b)
        {
            input1 = a;
            input2 = b;
        }
        
};

int calculator:: add() // we can add methods in class via :: operation
        {
            return input1+input2;
        }
int main() {
    calculator obj1;
    obj1.setIn(5,5);
  
  cout<<"sum is\n"<<obj1.add();
  
 

    return 0;
}
